import java.util.ArrayList;
import java.text.DecimalFormat;

public class ARN extends ArrayList<Nucleotide>{
    final private static DecimalFormat dec2 = new DecimalFormat("0.00");
    public static int nbCarbones = 0;
    public static int nbHydrogenes = 0;
    public static int nbAzotes = 0;
    public static int nbOxygenes = 0;
    public static double masseMolaireTotale = 0.00;
    
    //Verifie si le nombre de nucléotides est multiple de 3
    private static void multipleDeTrois(String entreeARN){
        if (entreeARN.length() % 3 !=0){
            System.err.println("La longueur d'une chaîne ARN doit être multiple de 3.");
            System.exit(1);
        }
    }
    
    //Vérifie si la longeur de l'ARN est minimalement 6 nucléotides
    private static void minimumSix(String entreeARN){
        if (entreeARN.length() < 6){
            System.err.println("La longueur d'une chaîne ARN doit être minimalement 6.");
            System.exit(2);
        }
    }
    
    //Vérifie si l'ARN contient seulement des lettres représentant des nucléotides
    private static void contientNucleotides(String entreeARN){
        char c = 'x';
        for (int i = 0 ; i < entreeARN.length() ; i++){
            c = entreeARN.charAt(i);
            if (!"ACGU".contains(""+c)){
                System.err.println("Une chaîne ARN doit être uniquement composée des lettres A, C, G, et U.");
                System.exit(3);
            }
        }
    }
        
    //Valide la chaîne ARN saisie par l'utilisateur
    private static boolean estARN(String entreeARN){
        multipleDeTrois(entreeARN);
        minimumSix(entreeARN);
        contientNucleotides(entreeARN);
        return true;
    }
    
    //Si la chaîne saisie est valide, construit un ArrayList de Nucleotide avec la chaîne saisie
    public static ARN construireARN(String entreeARN){
        ARN chaineARN = new ARN();
        if (estARN(entreeARN)){
            for(int i=0; i < entreeARN.length(); i++){
               chaineARN.add(new Nucleotide(entreeARN.charAt(i)));
            }
        }
        return chaineARN;
    }
    
    //Calcule les métriques de la chaîne créée
    public static void calculerStatsARN (String entreeARN){
        ARN chaineARN = construireARN(entreeARN);
        for(int i=0; i < entreeARN.length(); i++){
            nbCarbones += chaineARN.get(i).getNbCarbone();
            nbHydrogenes += chaineARN.get(i).getNbHydrogene();
            nbAzotes += chaineARN.get(i).getNbAzote();
            nbOxygenes += chaineARN.get(i).getNbOxygene();
            masseMolaireTotale += chaineARN.get(i).getMasseMolaire();
        }
    }
    
    //Affiche les métriques de la chaîne créée
    public static void afficherStatsARN(String entreeARN){
        calculerStatsARN(entreeARN);
        System.out.println("Nombre d'atomes d'Hydrogène: " + nbHydrogenes);
        System.out.println("Nombre d'atomes de Carbone: " + nbCarbones);
        System.out.println("Nombre d'atomes d'Azote: " + nbAzotes);
        System.out.println("Nombre d'atomes d'Oxygène: " + nbOxygenes);
        System.out.println("Masse molaire totale du ARN: " + dec2.format(masseMolaireTotale) + " g/mol");
    } 
}
