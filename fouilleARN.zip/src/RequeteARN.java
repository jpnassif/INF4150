public class RequeteARN {
    //Tableau de valeurs valides de recherche par acide aminé
    final private static String[] ACIDES_AMINES = {"Ala", "Arg", "Asn", "Asp", "Cys", 
                                                   "Glu", "Gln", "Gly", "His", "Ile", 
                                                   "Leu", "Lys", "Met", "Phe", "Pro", 
                                                   "Pyl", "Sec", "Ser", "Thr", "Trp", 
                                                   "Tyr", "Val"};
    //Chaîne de lettres valides pour recherche par nucléotides ou suite de nucléotides
    final private static String NUCLEOTIDES = "ABCDGHKMNRSUVWY";

    //Vérifie si la requête est de type Acide Aminé
    public static boolean estRequeteAcideAmine(String requete){
        boolean requeteAcideAmine = false;
        for (int i = 0; i < ACIDES_AMINES.length; i++){
            if (requete.equals(ACIDES_AMINES[i])){
                requeteAcideAmine = true;
                i = ACIDES_AMINES.length;
            }
        }
        return requeteAcideAmine;
    }
    
    //Vérifie si la requête est de type Suite Nucléotides
    public static boolean estRequeteSuiteNucleo(String requete){
        boolean requeteSuiteNucleo = true;
        if (requete.length() == 0 || requete.length() % 3 != 0){
            requeteSuiteNucleo = false;
        } else{
            for (int i = 0; i < requete.length(); i++){
                if (!NUCLEOTIDES.contains(""+requete.charAt(i))){
                    requeteSuiteNucleo = false;
                    i = requete.length();
                }
            }
        }
        return requeteSuiteNucleo;
    }

    //Effectue la requête selon le type saisi par l'utilisateur
    public static void faireRequeteARN (String entreeARN, String requete){
        if (estRequeteAcideAmine(requete)) {
            RequeteAcideAmine.effectuerRequeteAcideAmine(entreeARN, requete);
        } else if (estRequeteSuiteNucleo(requete)){
            RequeteSuiteNucleo.effectuerRequeteSuiteNucleo(entreeARN, requete);
        } else{
            System.out.println("Erreur! Vous devez entrer un acide aminé ou une suite de nucléotides ou appartenant"
                    + " à un groupement IUPAC de nucléotides et d'une longueur multiple de 3.");
            System.exit(2);
        }
    }     
}
