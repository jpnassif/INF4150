public class Nucleotide {
    protected char typeNucleo;
    protected int nbC;
    protected int nbH;
    protected int nbA;
    protected int nbO;
    protected double masseMolaire;
    
    //Constructeur Nucleotide
    public Nucleotide (char typeN){
        switch (typeN){
            case 'A':   
                typeNucleo = 'A';
                nbC = 5;
                nbH = 5;
                nbA = 5;
                nbO = 0;
                masseMolaire = 135.13;
                break;
            case 'C' :
                typeNucleo = 'C';
                nbC = 4;
                nbH = 5;
                nbA = 3;
                nbO = 1;
                masseMolaire = 111.10;
                break;
            case 'G' :
                typeNucleo = 'G';
                nbC = 5;
                nbH = 5;
                nbA = 5;
                nbO = 1;
                masseMolaire = 151.13;
                break;
            case 'U' :
                typeNucleo = 'U';
                nbC = 4;
                nbH = 4;
                nbA = 2;
                nbO = 2;
                masseMolaire = 112.09;
                break;
        }
    }
    
    //Retourne le type d'une nucléotide
    public char getTypeNucleo(){
        return typeNucleo;
    }
    
    //Retourne le nombre de carbones dans une nucléotide
    public int getNbCarbone (){
        return nbC;
    }
    
    //Retourne le nombre d'hydrogènes dans une nucléotide
    public int getNbHydrogene (){
        return nbH;
    }
    
    //Retourne le nombre d'azotes dans une nucléotide
    public int getNbAzote (){
        return nbA;
    }
    
    //Retourne le nombre d'oxygènes dans une nucléotide
    public int getNbOxygene (){
        return nbO;
    }
    
    //Retourne la masse molaire d'une nucléotide
    public double getMasseMolaire (){
        return masseMolaire;
    }
}
