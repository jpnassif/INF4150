import java.util.ArrayList;

public class RequeteAcideAmine {

    //Gere les differents cas de recherche et affiche les resultats.
    //@param entree La sequence d'ARN entree.
    //@param acideAmine L'acide amine entre.
    public static String choisirRequeteAcideAmine (String acideAmine) {
        String choixAcideAmine = "";    
        switch (acideAmine) {
            case "Ala":
                choixAcideAmine = ("GCU,GCC,GCA,GCG");
                break;

            case "Arg":
                choixAcideAmine = ("CGU,CGC,CGA,CGG,AGA,AGG");
                break;

            case "Asn":
                choixAcideAmine = ("AAU,AAC");
                break;

            case "Asp":
                choixAcideAmine = ("GAU,GAC");
                break;

            case "Cys":
                choixAcideAmine = ("UGU,UGC");
                break;

            case "Glu":
                choixAcideAmine = ("GAA,GAG");
                break;

            case "Gln":
                choixAcideAmine = ("CAA,CAG");
                break;

            case "Gly":
                choixAcideAmine = ("GGU,GGC,GGA,GGG");
                break;

            case "His":
                choixAcideAmine = ("CAU,CAC");
                break;

            case "Ile":
                choixAcideAmine = ("AUU,AUC,AUA");
                break;

            case "Leu":
                choixAcideAmine = ("UUA,UUG,CUU,CUC,CUA,CUG");
                break;

            case "Lys":
                choixAcideAmine = ("AAA,AAG");
                break;

            case "Met":
                choixAcideAmine = ("AUG");
                break;

            case "Phe":
                choixAcideAmine = ("UUU,UUC");
                break;

            case "Pro":
                choixAcideAmine = ("CCU,CCC,CCA,CCG");
                break;

            case "Pyl":
                choixAcideAmine = ("UAG");
                break;

            case "Sec":
                choixAcideAmine = ("UGA");
                break;

            case "Ser":
                choixAcideAmine = ("UCU,UCC,UCA,UCG,AGU,AGC");
                break;

            case "Thr":
                choixAcideAmine = ("ACU,ACC,ACA,ACG");
                break;

            case "Trp":
                choixAcideAmine = ("UGG");
                break;

            case "Tyr":
                choixAcideAmine = ("UAU,UAC");
                break;

            case "Val":
                choixAcideAmine = ("GUU,GUC,GUA,GUG");
                break;
        }
        return choixAcideAmine;
    }
    
    //Construit la chaîne représentant le codon en cour à l'indice donné
    public static String getCodon(ARN chaineARN, int indice){
        String codon="";
        for (int i = 0; i < 3; i++){
                codon += chaineARN.get(indice+i).getTypeNucleo();
            }
        return codon;
    }
    
    //Trouve les indices où l'on retrouve l'acide aminé demandé dans la séquence d'ARN
    //@param chaineARN La structure d'ARN entrée par l'utilisateur
    //@param acideAmine L'acide aminé entré par l'utilisateur
    //@return Un ArrayList d'entiers contenant les indices où l'on retrouve l'acide aminé demandé dans la séquence d'ARN
    public static ArrayList<Integer> requeteAcideAmine(ARN chaineARN, String acideAmine) {
        String choixAcideAmine = choisirRequeteAcideAmine(acideAmine);
        ArrayList<Integer> indices = new ArrayList<>();
        for(int i=0; i < chaineARN.size()-2; i+=3){
            if (choixAcideAmine.contains(getCodon(chaineARN,i))){
                indices.add(i);
            }
        }
        return indices;
    }

    //Affiche les indices où l'on retrouve l'acide aminé demandé dans la séquence d'ARN.
    //@param indices un ArrayList contenant les indices où l'on retrouve l'acide aminé demandé dans la séquence d'ARN.
    public static void effectuerRequeteAcideAmine (String entreeARN, String acideAmine) {
        ARN chaineARN = ARN.construireARN(entreeARN);
        ArrayList<Integer> indices = requeteAcideAmine (chaineARN, acideAmine);
        if ( indices.size() == 0){
            System.out.println("Aucun élément trouvé.");
        } else{
            System.out.print("résultat : " );
            for( int i = 0; i < indices.size()-1; ++i) {
                System.out.print((indices.get(i)+1)+", ");
            }
            System.out.print((indices.get(indices.size()-1)+1));
        }
    }
}
