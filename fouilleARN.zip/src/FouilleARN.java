import java.util.Scanner;

public class FouilleARN {
    
    //Affiche quelques statistiques sur l'ARN saisi
    public static void afficherStatsARN(String entreeARN){
        ARN.afficherStatsARN(entreeARN);
    }
    
    //Affiche les résultats de la recherche effectuée dans l'ARN
    public static void afficherResultatsRequete(String entreeARN, String requete){
        RequeteARN.faireRequeteARN(entreeARN, requete);
    }
    
    //Classe principale
    public static void main(String[] args) {
        Scanner saisie = new Scanner (System.in);
        //Saisie de la chaine ARN de l'utilisateur
        System.out.print( "Veuillez entrer une chaine ARN valide: " );
        String entreeARN = saisie.next();
        
        //Si la chaîne est valide, afficher les statistiques
        afficherStatsARN(entreeARN);
        
        //Saisie la requête de recherche d'ARN de l'utilisateur
        System.out.print( "Veuillez spécifier une requête de recherche dans l'ARN: " );
        String requete = saisie.next();

        //Si la requête est valide, afficher les résultats.
        afficherResultatsRequete(entreeARN, requete);
    }
}
